<?php

    /*
    Plugin Name: Wordpress Uploader
    Plugin URI: https://t.me/zerodayforums
    Description: This Uploader created by ph03n1x69 with WP mass shell uploader | Disclaimer : Author is not responsible for any action you made with this tools. Use this for educational purpose only.
    Version: 1.3.3.7
    Author URI: https://t.me/zerodayforums
    */

?>
