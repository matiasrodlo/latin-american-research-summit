<p class="qodef-m-order-details">
	<strong class="qodef-m-order-label"><?php esc_html_e( 'Total:', 'protalks-core' ); ?></strong><?php wc_cart_totals_subtotal_html(); ?>
</p>
