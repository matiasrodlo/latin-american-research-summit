<?php

include_once PROTALKS_CORE_INC_PATH . '/core-dashboard/class-protalkscore-dashboard.php';
