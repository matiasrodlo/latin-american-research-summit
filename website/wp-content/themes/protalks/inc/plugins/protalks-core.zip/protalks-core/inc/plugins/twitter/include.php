<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/twitter/helper.php';
