<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once PROTALKS_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once PROTALKS_CORE_PLUGINS_PATH . '/elementor/class-protalkscore-elementor-section-handler.php';
	include_once PROTALKS_CORE_PLUGINS_PATH . '/elementor/class-protalkscore-elementor-container-handler.php';
}
