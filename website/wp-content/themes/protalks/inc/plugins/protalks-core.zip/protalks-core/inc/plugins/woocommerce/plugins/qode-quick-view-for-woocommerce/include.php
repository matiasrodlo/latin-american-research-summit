<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/helper.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/template-functions.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-quick-view-for-woocommerce/class-protalkscore-qode-quick-view-for-woocommerce.php';
