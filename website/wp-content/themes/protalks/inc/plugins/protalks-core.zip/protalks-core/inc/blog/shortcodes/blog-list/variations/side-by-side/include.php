<?php

include_once PROTALKS_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/side-by-side/side-by-side.php';
