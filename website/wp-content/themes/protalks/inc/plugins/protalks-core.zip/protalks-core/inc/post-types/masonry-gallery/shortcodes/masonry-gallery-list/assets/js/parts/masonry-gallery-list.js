(function ( $ ) {
	'use strict';

	var shortcode = 'onegoal_core_masonry_gallery_list';

	qodefCore.shortcodes[shortcode]                    = {};
	qodefCore.shortcodes[shortcode].qodefMasonryLayout = qodef.qodefMasonryLayout;

})( jQuery );
