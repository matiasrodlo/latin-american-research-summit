<?php

get_header();

// Include cpt content template.
protalks_core_template_part( 'post-types/events', 'templates/content' );

get_footer();
