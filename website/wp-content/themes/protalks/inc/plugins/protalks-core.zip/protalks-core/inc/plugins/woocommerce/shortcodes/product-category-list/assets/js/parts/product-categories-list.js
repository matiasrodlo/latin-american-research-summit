(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.protalks_core_product_category_list                    = {};
	qodefCore.shortcodes.protalks_core_product_category_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.protalks_core_product_category_list.qodefSwiper        = qodef.qodefSwiper;

})( jQuery );
