<?php

include_once PROTALKS_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/class-protalkscore-dashboard-system-info-page.php';
