<?php

// Hook to include product mark.
do_action( 'protalks_core_action_woo_product_mark_info' );
