<?php

include_once PROTALKS_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-protalkscore-dashboard-import-page.php';
include_once PROTALKS_CORE_INC_PATH . '/core-dashboard/sub-pages/import/class-protalkscore-dashboard-import.php';
