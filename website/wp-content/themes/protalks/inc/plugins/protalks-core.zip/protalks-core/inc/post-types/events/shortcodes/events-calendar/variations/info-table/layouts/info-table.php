<div class="qodef-e-event-item">
	<?php protalks_core_list_sc_template_part( 'post-types/events/shortcodes/events-calendar', 'post-info/time', '', $params ); ?>
	<?php protalks_core_list_sc_template_part( 'post-types/events/shortcodes/events-calendar', 'post-info/title', '', $params ); ?>
	<?php protalks_core_list_sc_template_part( 'post-types/events/shortcodes/events-calendar', 'post-info/excerpt', '', $params ); ?>
</div>
