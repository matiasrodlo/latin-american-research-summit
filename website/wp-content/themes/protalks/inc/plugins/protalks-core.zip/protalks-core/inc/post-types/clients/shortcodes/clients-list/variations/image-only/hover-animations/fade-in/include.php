<?php

include_once PROTALKS_CORE_CPT_PATH . '/clients/shortcodes/clients-list/variations/image-only/hover-animations/fade-in/helper.php';
