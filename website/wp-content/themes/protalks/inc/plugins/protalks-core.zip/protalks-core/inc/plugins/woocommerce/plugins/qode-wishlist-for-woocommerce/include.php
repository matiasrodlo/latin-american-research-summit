<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/helper.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/template-functions.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/plugins/qode-wishlist-for-woocommerce/class-protalkscore-qode-wishlist-for-woocommerce.php';
