<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/class-protalkscore-woocommerce-dropdown-cart-widget.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/helper.php';
