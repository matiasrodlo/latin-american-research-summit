<?php

include_once PROTALKS_CORE_INC_PATH . '/icons/elegant-icons/class-protalkscore-elegant-icons-pack.php';
