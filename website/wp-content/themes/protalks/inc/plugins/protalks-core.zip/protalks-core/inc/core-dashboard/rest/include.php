<?php

include_once PROTALKS_CORE_INC_PATH . '/core-dashboard/rest/class-protalkscore-dashboard-rest-api.php';
