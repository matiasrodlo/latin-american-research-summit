<?php

include_once PROTALKS_CORE_INC_PATH . '/icons/font-awesome/class-protalkscore-font-awesome-pack.php';
