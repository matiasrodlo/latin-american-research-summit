<?php

include_once PROTALKS_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-protalkscore-blog-list-widget.php';
include_once PROTALKS_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-protalkscore-simple-blog-list-widget.php';
