<?php

include_once PROTALKS_CORE_CPT_PATH . '/events/shortcodes/events-list/variations/info-table/info-table.php';
