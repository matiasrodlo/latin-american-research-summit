<?php

include_once PROTALKS_CORE_INC_PATH . '/background-text/helper.php';
