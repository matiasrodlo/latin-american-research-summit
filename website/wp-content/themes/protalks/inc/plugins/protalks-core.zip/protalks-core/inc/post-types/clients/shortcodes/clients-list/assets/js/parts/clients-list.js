(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.protalks_core_clients_list             = {};
	qodefCore.shortcodes.protalks_core_clients_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
