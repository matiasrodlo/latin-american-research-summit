<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/helper.php';
include_once PROTALKS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/class-protalkscore-instagram-list-shortcode.php';
