<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/order-tracking/class-protalkscore-order-tracking-shortcode.php';
