<?php

include_once PROTALKS_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/info-below/info-below.php';
