<?php

include_once PROTALKS_CORE_INC_PATH . '/content/helper.php';
