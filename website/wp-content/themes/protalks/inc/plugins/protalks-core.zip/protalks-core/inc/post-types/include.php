<?php

include_once PROTALKS_CORE_CPT_PATH . '/class-protalkscore-custom-post-types.php';
