<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/woocommerce/class-protalkscore-woocommerce.php';
