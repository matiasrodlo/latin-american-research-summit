<?php

include_once PROTALKS_CORE_INC_PATH . '/media/helper.php';
