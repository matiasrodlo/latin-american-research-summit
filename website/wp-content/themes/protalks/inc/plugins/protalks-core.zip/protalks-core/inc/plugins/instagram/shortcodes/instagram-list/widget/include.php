<?php

include_once PROTALKS_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-protalkscore-instagram-list-widget.php';
