<?php

if ( ! defined( 'ABSPATH' ) ) {
	// Exit if accessed directly.
	exit;
}

require_once QODE_FRAMEWORK_INC_PATH . '/fonts/google-fonts.php';
require_once QODE_FRAMEWORK_INC_PATH . '/fonts/helper.php';
